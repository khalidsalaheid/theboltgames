(() => {
  const frame = document.getElementById('game-frame');
  const status = document.getElementById('player-status');
  const retry = document.getElementById('retry-game');
  const fullscreen = document.getElementById('fullscreen-game');
  const hint = 'Click inside the game to play. If it stays blank, try Retry or Open game.';

  // Cross-origin frames can fire load even for error pages. Never report that
  // a game is playable based on this event, or hide the recovery controls.
  frame.addEventListener('load', () => { status.textContent = hint; });
  frame.addEventListener('error', () => {
    status.textContent = 'The game could not be loaded. Try Retry or Open game.';
  });
  retry.hidden = false;
  retry.addEventListener('click', () => {
    status.textContent = 'Reloading the game. If it stays blank, try Open game.';
    frame.src = frame.getAttribute('src');
  });
  if (document.fullscreenEnabled && frame.requestFullscreen) {
    fullscreen.hidden = false;
    fullscreen.addEventListener('click', async () => {
      try {
        await frame.requestFullscreen();
        frame.focus();
      } catch {
        status.textContent = 'Fullscreen is unavailable. You can use Open game instead.';
      }
    });
  }
})();
