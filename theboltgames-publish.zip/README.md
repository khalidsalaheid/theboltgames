# TheBoltGames — original browser game directory

Static HTML site with ten game pages. Each game runs in an external host's iframe; game binaries are not stored in this repository.

## Local preview

Run `python3 -m http.server 8000` from this folder and open `http://localhost:8000/`.
Links are relative, so the same files work at a domain root or under a path such as `/theboltgames/`.

## Regression tests

Requires Node.js 20 or newer:

```sh
npm ci
npx playwright install chromium
npm test
```

The browser tests click all ten cards at both hosting paths, check Back and Privacy navigation, exercise iframe retry, verify mobile player dimensions, and check recovery controls after network/fullscreen failures. External responses are mocked in these tests so third-party outages cannot conceal a local navigation regression. They do not establish live game availability.

## Player maintenance

Each game folder's `index.html` contains the iframe source and matching Open game link. Update both when changing a host. `player.css` and `player.js` provide the shared layout, retry and fullscreen controls. Links and frames work without JavaScript; enhanced buttons are shown when supported.

A cross-origin iframe's `load` event cannot prove that its game started. The player deliberately keeps recovery controls visible even after that event. Open game lets the visitor try the source in a separate tab if embedding fails. External hosts, network policies, and browser WebGL support can still affect play.

## Hosting note (October 26, 2026)

`theboltgames.com` currently redirects to `www.theboltgames.com`, which serves the separate Bolt Games studio site. Committing this repository does not change that site's domain mapping. The existing `CNAME` is retained; hosting/domain settings need to be considered separately before publishing this directory. No studio repository or domain configuration was modified by the game-loading repair.

## Live browser verification — October 26, 2026

Tested the repaired local site in Chromium with WebGL enabled, entering each page through its homepage card:

| Game | Observed result |
| --- | --- |
| Slope | Started a run using the replacement host; two optional host images returned 404. |
| Snow Rider 3D | Replacement host reached a run and score/restart screen. |
| Run 3 | Started a tunnel run. |
| Snake | Started a round and reached the game-over screen. |
| Drift Hunters | Selected a track and reached the driving scene. |
| Basketball Random | Selected one player and reached the court; host script errors did not stop play. |
| Fireboy & Watergirl 3 | Entered the first level; an external analytics JSON error did not stop play. |
| Stickman Parkour | Dismissed the host's ad and entered level 1. |
| Basket Hoop | Passed the splash screen and reached the interactive tap-to-dunk tutorial. |
| Drift Boss | Passed booster selection and entered the driving tutorial. |

These are startup smoke checks, not full-game or all-device certification. The mobile checks cover our toolbar and player area, not every external game's touch controls. The original Slope host returned a blocking 403 page. The original Snow Rider host returned 403 to an HTTP probe but loaded an extra Play gate in Chromium; its replacement reached the game directly. The eight remaining sources were retained after browser checks.
