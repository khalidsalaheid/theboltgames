const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('node:http');
const { readFile } = require('node:fs/promises');
const path = require('node:path');
const { chromium } = require('playwright');
const root = path.resolve(__dirname, '..');
let browser, server, origin;
before(async () => {
  server = createServer(async (req, res) => {
    let name = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    name = name.replace(/^\/theboltgames(?=\/)/, '');
    if (name.endsWith('/')) name += 'index.html';
    const file = path.resolve(root, '.' + name);
    if (!file.startsWith(root + path.sep)) { res.writeHead(403).end(); return; }
    try {
      const data = await readFile(file);
      res.setHeader('Content-Type', ({'.html':'text/html','.js':'text/javascript','.css':'text/css'})[path.extname(file)] || 'application/octet-stream');
      res.end(data);
    } catch { res.writeHead(404).end(); }
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  origin = `http://127.0.0.1:${server.address().port}`;
  browser = await chromium.launch();
});
after(async () => { await browser?.close(); await new Promise(resolve => server.close(resolve)); });

for (const base of ['/', '/theboltgames/']) {
  test(`all ten cards, players, retry and back links at ${base}`, async () => {
    const page = await browser.newPage();
    const requests = [];
    // Isolate our routing/controls from third-party uptime. Live gameplay is a separate manual check.
    await page.route('**/*', route => {
      const url = route.request().url();
      if (url.startsWith(origin)) return route.continue();
      requests.push(url);
      return route.fulfill({contentType:'text/html', body:'<button>Mock game</button>'});
    });
    await page.goto(origin + base);
    const links = await page.locator('.game-card').evaluateAll(cards => cards.map(c => c.getAttribute('href')));
    assert.equal(links.length, 10);
    for (const href of links) {
      await page.locator(`.game-card[href="${href}"]`).click();
      assert.equal(page.url(), new URL(href, origin + base).href);
      const frame = page.locator('#game-frame');
      const src = await frame.getAttribute('src');
      assert.ok(src.startsWith('https://'));
      assert.ok(await frame.getAttribute('title'));
      assert.equal(await page.getByRole('link', {name:'Open game'}).getAttribute('href'), src);
      await page.frameLocator('#game-frame').getByRole('button', {name:'Mock game'}).waitFor();
      const beforeRetry = requests.filter(u => u === src).length;
      await page.getByRole('button', {name:'Retry', exact:true}).click();
      await page.frameLocator('#game-frame').getByRole('button', {name:'Mock game'}).waitFor();
      assert.ok(requests.filter(u => u === src).length > beforeRetry);
      await page.setViewportSize({width:390,height:844});
      const box = await frame.boundingBox();
      assert.ok(box.height > 400 && box.width <= 390);
      assert.ok(box.y + box.height <= 845);
      await page.getByRole('link', {name:'← Back'}).click();
      assert.equal(page.url(), origin + base);
    }
    await page.getByRole('link', {name:'Privacy Policy'}).click();
    assert.equal(page.url(), origin + base + 'privacy.html');
    await page.close();
  });
}
test('failed external frame retains recovery; fullscreen failure is handled', async () => {
  const page = await browser.newPage();
  await page.route('**/*', route => route.request().url().startsWith(origin) ? route.continue() : route.abort());
  await page.goto(origin + '/slope/');
  assert.ok(await page.getByRole('button', {name:'Retry', exact:true}).isVisible());
  assert.ok(await page.getByRole('link', {name:'Open game'}).isVisible());
  assert.match(await page.locator('#player-status').innerText(), /Retry|Open game/);
  await page.evaluate(() => { document.getElementById('game-frame').requestFullscreen = () => Promise.reject(new Error('Unavailable')); });
  await page.getByRole('button', {name:'Fullscreen', exact:true}).click();
  await page.getByRole('status').filter({hasText:'Fullscreen is unavailable'}).waitFor();
  await page.close();
});
test('game links and external fallback remain available without JavaScript', async () => {
  const page = await browser.newPage({javaScriptEnabled:false});
  await page.route('**/*', route => route.request().url().startsWith(origin) ? route.continue() : route.fulfill({body:'Game placeholder'}));
  await page.goto(origin + '/theboltgames/');
  await page.locator('.game-card').first().click();
  assert.equal(page.url(), origin + '/theboltgames/slope/');
  assert.ok(await page.getByRole('link', {name:'Open game'}).isVisible());
  assert.equal(await page.getByRole('button', {name:'Retry', exact:true}).count(), 0);
  await page.getByRole('link', {name:'← Back'}).click();
  assert.equal(page.url(), origin + '/theboltgames/');
  await page.close();
});
